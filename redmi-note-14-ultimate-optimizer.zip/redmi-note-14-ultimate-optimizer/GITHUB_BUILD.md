# Compilar pelo GitHub Actions

O projeto já inclui `.github/workflows/android.yml`. Esse workflow compila automaticamente o APK debug em um runner Ubuntu do GitHub, que possui arquitetura e ferramentas compatíveis.

## Passos

1. Crie um repositório vazio no GitHub.
2. Extraia o ZIP do projeto.
3. Na pasta do projeto, inicialize o Git e envie os arquivos:

```bash
git init
git branch -M main
git add .
git commit -m "Initial Android project"
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

4. No GitHub, abra a aba **Actions**.
5. Selecione **Android APK**.
6. Aguarde a execução terminar.
7. Abra a execução concluída e baixe o artefato `redmi-note-14-ultimate-optimizer-debug`.
8. Extraia o artefato; ele contém `app-debug.apk`.

O workflow instala JDK 17, Android SDK Platform 36, Build-Tools 36.0.0 e executa `./gradlew assembleDebug`. O APK gerado é de teste e não é uma versão de release assinada para publicação.

## Executar manualmente

Para iniciar sem fazer um novo commit, use **Actions > Android APK > Run workflow**. Essa opção aparece após o primeiro push do arquivo de workflow.

## Instalar no Redmi Note 14

Ative as opções de desenvolvedor e a depuração USB no celular. Depois conecte-o a um computador com ADB e rode:

```bash
adb install -r app-debug.apk
```

Ou transfira o arquivo para o celular e abra-o pelo gerenciador de arquivos, autorizando a instalação de fontes desconhecidas quando solicitado.

## Se a compilação falhar

Abra o job **Build debug APK**, expanda **Build debug APK** e leia a primeira mensagem de erro Kotlin/Gradle. O SDK e o Gradle já são preparados pelo workflow; não adicione `local.properties` ao repositório. O arquivo `local.properties.example` serve apenas como referência para compilação local.
