package com.redmi.ultimateoptimizer

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private val Background = Color(0xFF0B0D10)
private val Panel = Color(0xFF15181D)
private val PanelElevated = Color(0xFF1D2229)
private val Accent = Color(0xFFFF453A)
private val Muted = Color(0xFF9AA3AF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RedmiOptimizerApp() }
    }
}

data class DeviceSnapshot(
    val model: String,
    val android: String,
    val hyperOs: String,
    val storage: String,
    val storageProgress: Float,
    val ram: String,
    val battery: String,
    val charging: String,
    val temperature: String,
    val network: String
)

data class AppItem(val label: String, val packageName: String, val isGame: Boolean)

data class LogItem(val time: String, val message: String)

enum class Section(val label: String) { HOME("Início"), OPTIMIZE("Otimização"), GAMES("Jogos"), BATTERY("Bateria"), SETTINGS("Configurações") }

@Composable
fun RedmiOptimizerApp() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf(Section.HOME) }
    var snapshot by remember { mutableStateOf(readSnapshot(context)) }
    var logs by remember { mutableStateOf(loadLogs(context)) }
    var showRestore by remember { mutableStateOf(false) }
    var isAnalyzing by remember { mutableStateOf(false) }

    fun log(message: String) {
        val updated = (listOf(LogItem(now(), message)) + logs).take(30)
        logs = updated
        saveLogs(context, updated)
    }

    fun refresh() {
        isAnalyzing = true
        snapshot = readSnapshot(context)
        log("Análise concluída: dados coletados pelas APIs públicas disponíveis.")
        isAnalyzing = false
    }

    MaterialTheme(colorScheme = darkColors()) {
        Scaffold(
            containerColor = Background,
            topBar = { AppTopBar(selected) },
            bottomBar = {
                NavigationBar(containerColor = Panel, modifier = Modifier.navigationBarsPadding()) {
                    Section.values().forEach { section ->
                        NavigationBarItem(
                            selected = selected == section,
                            onClick = { selected = section },
                            icon = { Icon(sectionIcon(section), contentDescription = section.label) },
                            label = { Text(section.label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (selected) {
                    Section.HOME -> HomeScreen(snapshot, logs, isAnalyzing, ::refresh, ::log, { selected = Section.OPTIMIZE })
                    Section.OPTIMIZE -> OptimizeScreen(context, snapshot, logs, ::log)
                    Section.GAMES -> GamesScreen(context, ::log)
                    Section.BATTERY -> BatteryScreen(context, snapshot, ::log)
                    Section.SETTINGS -> SettingsScreen(context, logs, ::log, { showRestore = true })
                }
            }
        }
    }

    if (showRestore) {
        AlertDialog(
            onDismissRequest = { showRestore = false },
            containerColor = PanelElevated,
            title = { Text("Restaurar configurações") },
            text = { Text("Este app não altera configurações protegidas automaticamente. Não há alterações próprias pendentes para restaurar. Ajustes manuais devem ser revertidos nas telas oficiais do Android.") },
            confirmButton = { TextButton(onClick = { log("Restauração verificada: nenhuma alteração automática encontrada."); showRestore = false }) { Text("Entendi") } },
            dismissButton = { TextButton(onClick = { showRestore = false }) { Text("Cancelar") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppTopBar(section: Section) {
    TopAppBar(
        title = { Column { Text("REDMI OPTIMIZER", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp); Text(section.label, color = Muted, fontSize = 12.sp) } },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Background, titleContentColor = Color.White),
        actions = { Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = Accent, modifier = Modifier.padding(end = 18.dp)) }
    )
}

@Composable
private fun HomeScreen(snapshot: DeviceSnapshot, logs: List<LogItem>, analyzing: Boolean, refresh: () -> Unit, log: (String) -> Unit, openOptimize: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Visão geral", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Leitura real do dispositivo · sem root", color = Muted, fontSize = 13.sp)
        }
        item { DeviceCard(snapshot) }
        item {
            Button(onClick = refresh, enabled = !analyzing, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(14.dp)) {
                Text(if (analyzing) "ANALISANDO..." else "ANALISAR CELULAR", fontWeight = FontWeight.Bold)
            }
            if (analyzing) LinearProgressIndicator(color = Accent, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
        }
        item { Button(onClick = { log("Otimização segura iniciada: recomendações abertas; nenhuma alteração protegida foi forçada."); openOptimize() }, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = PanelElevated), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.CleaningServices, null, tint = Accent); Spacer(Modifier.size(8.dp)); Text("OTIMIZAR COM SEGURANÇA") } }
        item { SectionTitle("Últimas atividades") }
        if (logs.isEmpty()) item { EmptyState("Nenhuma operação registrada ainda.") } else items(logs.take(4)) { LogRow(it) }
    }
}

@Composable
private fun DeviceCard(s: DeviceSnapshot) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.PhoneAndroid, null, tint = Accent, modifier = Modifier.size(28.dp)); Spacer(Modifier.size(10.dp)); Column { Text(s.model, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("Android ${s.android} · HyperOS ${s.hyperOs}", color = Muted, fontSize = 12.sp) } }
            HorizontalInfo("Armazenamento", s.storage, s.storageProgress, Icons.Default.Storage)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { SmallInfo("Bateria", s.battery, Icons.Default.BatteryChargingFull); SmallInfo("Temperatura", s.temperature, Icons.Default.Thermostat); SmallInfo("Rede", s.network, Icons.Default.NetworkCheck) }
        }
    }
}

@Composable
private fun HorizontalInfo(title: String, value: String, progress: Float, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column { Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.size(7.dp)); Text(title, color = Muted, fontSize = 12.sp); Spacer(Modifier.weight(1f)); Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }; LinearProgressIndicator(progress = { progress }, color = Accent, trackColor = PanelElevated, modifier = Modifier.fillMaxWidth().padding(top = 7.dp)) }
}

@Composable
private fun SmallInfo(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelElevated), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(10.dp)) { Icon(icon, null, tint = Accent, modifier = Modifier.size(17.dp)); Text(title, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp)); Text(value, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) } }
}

@Composable
private fun OptimizeScreen(context: Context, snapshot: DeviceSnapshot, logs: List<LogItem>, log: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Otimização segura", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Ações permitidas e ajustes manuais, sem forçar configurações protegidas.", color = Muted, fontSize = 13.sp) }
        item { RecommendationCard("Fluidez", "Ajuste as escalas de animação em Opções do desenvolvedor para 0,5x. O Android exige ação manual.", Icons.Default.DeveloperMode) { open(context, Settings.ACTION_SETTINGS); log("Tela de configurações aberta para ajustes manuais de fluidez.") } }
        item { RecommendationCard("Armazenamento", "Revise arquivos grandes e downloads antes de excluir. Nada pessoal é apagado automaticamente.", Icons.Default.Storage) { open(context, Settings.ACTION_INTERNAL_STORAGE_SETTINGS); log("Tela de armazenamento aberta para revisão manual.") } }
        item { RecommendationCard("Aplicativos em segundo plano", "O Android controla processos protegidos. Abra informações do app para revisar bateria e atividade.", Icons.Default.PhoneAndroid) { open(context, Settings.ACTION_APPLICATION_SETTINGS); log("Gerenciador de aplicativos aberto.") } }
        item { RecommendationCard("Conectividade", "Diagnóstico básico: ${snapshot.network}. DNS, APN e VPN não são alterados automaticamente.", Icons.Default.NetworkCheck) { open(context, Settings.ACTION_WIRELESS_SETTINGS); log("Configurações de conectividade abertas.") } }
        item { RecommendationCard("Ping no Roblox", "O ping depende da rota até o servidor da partida. Prefira Wi‑Fi 5 GHz perto do roteador, pause downloads e compare com rede móvel; este app não altera o ping artificialmente.", Icons.Default.NetworkCheck) { open(context, Settings.ACTION_WIFI_SETTINGS); log("Wi‑Fi aberto para revisão de sinal e banda; nenhuma configuração foi alterada.") } }
        item { SectionTitle("Histórico") }
        items(logs) { LogRow(it) }
    }
}

@Composable
private fun GamesScreen(context: Context, log: (String) -> Unit) {
    val games = remember { findGames(context) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Centro de jogos", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Sem injeção, alteração de memória ou promessa artificial de FPS.", color = Muted, fontSize = 13.sp) }
        item { RecommendationCard("Game Turbo / recursos do fabricante", "A disponibilidade depende do HyperOS. O botão abre a tela oficial quando encontrada.", Icons.Default.Gamepad) { open(context, Settings.ACTION_SETTINGS); log("Configurações abertas para localizar Game Turbo manualmente.") } }
        item { RecommendationCard("Não Perturbe", "Ative manualmente durante jogos para preservar notificações importantes sob seu controle.", Icons.Default.Gamepad) { open(context, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS); log("Tela de acesso ao Não Perturbe aberta.") } }
        item { SectionTitle("Jogos detectados (${games.size})") }
        if (games.isEmpty()) item { EmptyState("Nenhum jogo exposto pelo catálogo público do Android.") } else items(games) { AppRow(it) { launchPackage(context, it.packageName); log("Jogo aberto: ${it.label}.") } }
    }
}

@Composable
private fun BatteryScreen(context: Context, snapshot: DeviceSnapshot, log: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Bateria e temperatura", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item { StatusCard("Carga", snapshot.battery, "Estado: ${snapshot.charging}", Icons.Default.BatteryChargingFull) }
        item { StatusCard("Temperatura", snapshot.temperature, "Valor fornecido pelo BatteryManager quando disponível.", Icons.Default.Thermostat) }
        item { RecommendationCard("Economia de bateria", "Use a tela oficial do Android para escolher a economia adequada. Proteções térmicas não são alteradas.", Icons.Default.BatteryChargingFull) { open(context, Settings.ACTION_BATTERY_SAVER_SETTINGS); log("Tela de economia de bateria aberta.") } }
        item { Text("Boas práticas", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item { Text("Reduza brilho, evite jogar enquanto carrega, use carregador compatível e mantenha o aparelho ventilado. Software não consegue resfriar fisicamente o dispositivo.", color = Muted, fontSize = 14.sp) }
    }
}

@Composable
private fun SettingsScreen(context: Context, logs: List<LogItem>, log: (String) -> Unit, restore: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Configurações e segurança", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Permissões mínimas e transparência operacional.", color = Muted, fontSize = 13.sp) }
        item { RecommendationCard("Permissões do otimizador", "Este app usa apenas estado da rede. Bateria, armazenamento e apps vêm de APIs públicas; nenhum acesso especial é solicitado.", Icons.Default.Lock) { open(context, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, context.packageName); log("Detalhes de permissões do otimizador abertos.") } }
        item { RecommendationCard("Privacidade", "Os logs ficam localmente no aparelho e não contêm dados pessoais. Não há coleta ou envio automático.", Icons.Default.Info) { log("Política local consultada.") } }
        item { RecommendationCard("Atualizações e Play Protect", "Use as telas oficiais do sistema e da Play Store. Este app nunca desativa mecanismos de proteção.", Icons.Default.Lock) { open(context, Settings.ACTION_SECURITY_SETTINGS); log("Configurações de segurança abertas.") } }
        item { OutlinedButton(onClick = restore, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Icon(Icons.Default.Restore, null, tint = Accent); Spacer(Modifier.size(8.dp)); Text("RESTAURAR CONFIGURAÇÕES DO APP") } }
        item { SectionTitle("Log completo (${logs.size})") }
        items(logs) { LogRow(it) }
    }
}

@Composable
private fun RecommendationCard(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = action), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Accent, modifier = Modifier.size(26.dp)); Spacer(Modifier.size(13.dp)); Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(body, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp)) } } }
}

@Composable
private fun StatusCard(title: String, value: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Accent, modifier = Modifier.size(30.dp)); Spacer(Modifier.size(13.dp)); Column { Text(title, color = Muted, fontSize = 12.sp); Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 12.sp) } } } }

@Composable
private fun AppRow(app: AppItem, action: () -> Unit) { Card(Modifier.fillMaxWidth().clickable(onClick = action), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (app.isGame) Icons.Default.Gamepad else Icons.Default.PhoneAndroid, null, tint = Accent); Spacer(Modifier.size(12.dp)); Column { Text(app.label, color = Color.White, fontWeight = FontWeight.SemiBold); Text(app.packageName, color = Muted, fontSize = 11.sp) } } } }

@Composable private fun LogRow(log: LogItem) { Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)) { Text(log.time, color = Accent, fontSize = 11.sp, modifier = Modifier.size(width = 55.dp, height = 40.dp)); Text(log.message, color = Muted, fontSize = 12.sp) } }
@Composable private fun SectionTitle(text: String) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(top = 4.dp)) }
@Composable private fun EmptyState(text: String) { Text(text, color = Muted, modifier = Modifier.padding(vertical = 10.dp)) }

private fun darkColors() = androidx.compose.material3.darkColorScheme(primary = Accent, secondary = Accent, background = Background, surface = Panel, onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White)

private fun sectionIcon(section: Section) = when (section) { Section.HOME -> Icons.Default.Home; Section.OPTIMIZE -> Icons.Default.CleaningServices; Section.GAMES -> Icons.Default.Gamepad; Section.BATTERY -> Icons.Default.BatteryChargingFull; Section.SETTINGS -> Icons.Default.Settings }

private fun readSnapshot(context: Context): DeviceSnapshot {
    val stat = StatFs(Environment.getDataDirectory().path)
    val total = stat.totalBytes.coerceAtLeast(1L); val free = stat.availableBytes.coerceAtLeast(0L); val used = total - free
    val batteryIntent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
    val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
    val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = when (status) { BatteryManager.BATTERY_STATUS_CHARGING -> "Carregando"; BatteryManager.BATTERY_STATUS_FULL -> "Completa"; BatteryManager.BATTERY_STATUS_DISCHARGING -> "Descarregando"; else -> "Indisponível" }
    val temp = if (tempTenths != Int.MIN_VALUE) String.format(Locale.US, "%.1f°C", tempTenths / 10f) else "Indisponível"
    val connectivity = context.getSystemService(ConnectivityManager::class.java)
    val caps = connectivity.activeNetwork?.let { connectivity.getNetworkCapabilities(it) }
    val network = when { caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"; caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Móvel"; caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"; else -> "Indisponível" }
    val ram = context.getSystemService(android.app.ActivityManager::class.java)?.let { info -> android.app.ActivityManager.MemoryInfo().also { info.getMemoryInfo(it) }.let { "${formatBytes(it.availMem)} livres" } } ?: "Indisponível"
    return DeviceSnapshot(android.os.Build.MODEL.ifBlank { "Modelo indisponível" }, android.os.Build.VERSION.RELEASE ?: "Indisponível", detectHyperOs(), "${formatBytes(used)} / ${formatBytes(total)}", (used.toFloat() / total).coerceIn(0f, 1f), ram, if (level >= 0) "$level%" else "Indisponível", charging, temp, network)
}

private fun detectHyperOs() = System.getProperty("ro.miui.ui.version.name") ?: "Indisponível"
private fun findGames(context: Context): List<AppItem> = context.packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_GAME), 0).map { AppItem(it.loadLabel(context.packageManager).toString(), it.activityInfo.packageName, true) }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
private fun launchPackage(context: Context, packageName: String) { context.packageManager.getLaunchIntentForPackage(packageName)?.let(context::startActivity) }
private fun open(context: Context, action: String, packageName: String? = null) { runCatching { context.startActivity(Intent(action).apply { packageName?.let { data = android.net.Uri.parse("package:$it") } }) } }
private fun formatBytes(bytes: Long): String { val units = arrayOf("B", "KB", "MB", "GB", "TB"); var value = bytes.toDouble(); var index = 0; while (value >= 1024 && index < units.lastIndex) { value /= 1024; index++ }; return String.format(Locale.US, "%.1f %s", value, units[index]) }
private fun now() = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
private fun loadLogs(context: Context): List<LogItem> = context.getSharedPreferences("logs", Context.MODE_PRIVATE).getStringSet("items", emptySet()).orEmpty().mapNotNull { it.split("|", limit = 2).takeIf { p -> p.size == 2 }?.let { LogItem(it[0], it[1]) } }.sortedByDescending { it.time }
private fun saveLogs(context: Context, logs: List<LogItem>) { context.getSharedPreferences("logs", Context.MODE_PRIVATE).edit().putStringSet("items", logs.map { "${it.time}|${it.message}" }.toSet()).apply() }
