# Redmi Note 14 Ultimate Optimizer

Aplicativo Android nativo em Kotlin/Jetpack Compose para diagnóstico transparente e atalhos seguros no Xiaomi Redmi Note 14. O projeto não exige root, bootloader desbloqueado, VPN, acessibilidade ou administrador do dispositivo.

## Estado da entrega

Este projeto foi criado como uma base nativa separada do projeto Expo `/home/ubuntu/redmiopt`. O ambiente de criação não possui Android SDK nem Gradle instalados; portanto, o APK **não foi compilado nem instalado por este ambiente**. A compilação deve ser feita no Android Studio com o SDK Android 36 instalado.

## Requisitos

- Android Studio Ladybug 2024.2.1 Patch 2 ou mais recente.
- JDK 17 (o Android Studio pode usar o JDK embutido).
- Android SDK Platform 36 e Build-Tools compatíveis.
- Um Redmi Note 14 com Depuração USB habilitada para instalação por cabo.

## Abrir e compilar

1. Extraia o ZIP ou abra diretamente a pasta `redmi-note-14-ultimate-optimizer` no Android Studio.
2. Escolha **Open** e selecione a pasta que contém `settings.gradle.kts`.
3. Aceite a sincronização do Gradle e aguarde o download das dependências.
4. Em **Tools > SDK Manager**, instale **Android API 36** e uma versão recente de **Android SDK Build-Tools**.
5. Selecione o módulo `app` e a variante `debug`.
6. Use **Build > Make Project** para validar a compilação.
7. Para gerar APK de teste: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. O APK debug costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.
9. Conecte o Redmi Note 14, autorize a depuração USB e use **Run** ou instale pelo terminal:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Para uma versão assinada de distribuição, configure um keystore em **Build > Generate Signed Bundle / APK**. Nenhum keystore ou senha foi incluído no projeto.

## Compilação no GitHub

O projeto inclui o workflow `.github/workflows/android.yml`, que instala JDK 17, Android SDK Platform 36 e Build-Tools 36.0.0 no GitHub Actions e publica o `app-debug.apk` como artefato. Veja [GITHUB_BUILD.md](GITHUB_BUILD.md) para os comandos de envio ao GitHub e download do APK.

## Funcionalidades implementadas

- Dashboard com modelo, versão Android, tentativa de leitura da versão HyperOS, armazenamento usado/livre, RAM disponível, bateria, estado de carregamento, temperatura e conectividade.
- Análise real acionada pelo usuário usando `StatFs`, `BatteryManager`, `ActivityManager` e `ConnectivityManager`.
- Módulo de otimização segura com atalhos para configurações oficiais de armazenamento, aplicativos, conectividade e opções de desenvolvedor.
- Orientações de ajustes manuais; o app não altera configurações protegidas.
- Detecção de jogos expostos pelo `CATEGORY_GAME`, abertura dos jogos e atalho para Não Perturbe.
- Tela de bateria e temperatura com dados de `ACTION_BATTERY_CHANGED` quando o sistema disponibiliza o valor.
- Tela de segurança e privacidade, permissões mínimas e atalho para configurações oficiais.
- Orientações para latência no Roblox: usar Wi‑Fi 5 GHz com sinal forte, pausar downloads, fechar streaming e comparar rotas; o app não falsifica nem reduz ping por software.
- Logs locais de operações, sem envio automático e sem dados pessoais.
- Confirmação e mensagem de restauração: como o app não altera configurações protegidas automaticamente, não há valores externos falsificados para restaurar.
- Tratamento seguro de atalhos indisponíveis; o app não força ações invasivas.

## Limitações intencionais

Aplicativos comuns não podem limpar cache privado de outros apps, ler consumo detalhado de bateria de todos os pacotes, modificar escalas de animação protegidas, controlar processos continuamente, alterar APN/DNS, controlar limites térmicos ou abrir APIs privadas do HyperOS. Nesses casos, o aplicativo abre a tela oficial ou informa `Indisponível`.

### Sobre o ping no Roblox

O ping mostrado dentro de uma partida é determinado pela rota entre a operadora/roteador e o servidor específico daquela partida. Nenhum aplicativo comum consegue garantir redução de ping sem trocar a rota ou o provedor. Para tentar reduzir a latência de forma segura: use Wi‑Fi 5 GHz quando estiver perto do roteador, evite repetidores congestionados, pause downloads/streaming, feche VPN, teste outra rede e mantenha o aparelho com sinal forte. O aplicativo não altera DNS, APN, VPN, arquivos do Roblox ou servidores de jogo.

A permissão `BATTERY_STATS` é protegida pelo sistema e não é usada. A listagem de jogos usa apenas intents públicos do Android. O app não inclui `QUERY_ALL_PACKAGES`, acessibilidade, VPN, administrador, localização, contatos ou armazenamento amplo.

## Estrutura

- `app/src/main/java/com/redmi/ultimateoptimizer/MainActivity.kt`: UI Compose, leitura de dados e módulos.
- `app/src/main/AndroidManifest.xml`: atividade e permissões mínimas.
- `app/src/main/res/values/themes.xml`: tema escuro.
- `build.gradle.kts` e `app/build.gradle.kts`: toolchain Android/Kotlin/Compose.

## Privacidade

Consulte `PRIVACY_POLICY.md`. Os logs são armazenados somente no armazenamento privado do app e podem ser apagados ao limpar os dados do aplicativo pelas configurações do Android.
