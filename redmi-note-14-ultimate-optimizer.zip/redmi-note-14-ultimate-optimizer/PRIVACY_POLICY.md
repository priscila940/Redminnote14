# Política de Privacidade

O Redmi Note 14 Ultimate Optimizer foi projetado para funcionar localmente no aparelho.

## Dados acessados

O app lê informações técnicas disponíveis pelas APIs públicas do Android: modelo, versão do sistema, armazenamento, memória disponível, bateria, temperatura quando fornecida, estado de carregamento, tipo de conectividade e jogos expostos pelo catálogo público de intents.

## Armazenamento local

O histórico de operações é salvo em preferências privadas do aplicativo. Não há conta, servidor próprio, analytics, publicidade, coleta de contatos, localização, fotos ou arquivos pessoais.

## Exclusões e alterações

O aplicativo não exclui arquivos automaticamente e não modifica configurações protegidas. Ações que dependem de autorização do usuário abrem as telas oficiais do Android. O usuário pode remover o histórico limpando os dados do app nas configurações do sistema.

## Compartilhamento

Nenhum dado é enviado automaticamente para terceiros pelo código deste projeto.

## Contato e alterações

Distribuidores devem substituir este documento por seus dados de contato e revisar a política antes de publicar o APK em uma loja.
